## python version
Python 3.9.17

## packages
pip install -r requirements.txt

## execution
python3.9 main.py